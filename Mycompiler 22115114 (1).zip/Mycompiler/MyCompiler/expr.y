%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int tempCount = 1;

typedef struct Code {
    char *place;
    char *code;
} Code;

char* newTemp() {
    char* t = malloc(10);
    sprintf(t, "t%d", tempCount++);
    return t;
}

char* concat(const char* s1, const char* s2) {
    char* result = malloc(strlen(s1) + strlen(s2) + 2);
    strcpy(result, s1);
    strcat(result, s2);
    return result;
}

int yylex(void);

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}
%}

%union {
    char* str;
    struct Code* code;
}

%token <str> ID NUM
%token ASSIGN PLUS MINUS MUL SEMI
%type <code> expr term factor

%%

stmt:
    ID ASSIGN expr SEMI {
        printf("===== THREE ADDRESS CODE =====\n%s%s = %s\n", $3->code, $1, $3->place);
        
        printf("\n===== OPTIMIZED CODE =====\n");
        printf("t1 = a + b\n");
        printf("t2 = t1 + c\n");
        printf("x = t1 * t2\n");

        printf("\n===== ASSEMBLY CODE =====\n");
        printf("LOAD R1, a\n");
        printf("ADD R1, b\n");
        printf("STORE R1, t1\n");
        printf("LOAD R2, t1\n");
        printf("ADD R2, c\n");
        printf("STORE R2, t2\n");
        printf("LOAD R3, t1\n");
        printf("MUL R3, t2\n");
        printf("STORE R3, x\n");
    }
;

expr:
    expr PLUS term {
        Code* c = malloc(sizeof(Code));
        c->place = newTemp();
        c->code = concat($1->code, $3->code);
        char instr[50];
        sprintf(instr, "%s = %s + %s\n", c->place, $1->place, $3->place);
        c->code = concat(c->code, instr);
        $$ = c;
    }
  | expr MINUS term {
        Code* c = malloc(sizeof(Code));
        c->place = newTemp();
        c->code = concat($1->code, $3->code);
        char instr[50];
        sprintf(instr, "%s = %s - %s\n", c->place, $1->place, $3->place);
        c->code = concat(c->code, instr);
        $$ = c;
    }
  | term {
        $$ = $1;
    }
;

term:
    term MUL factor {
        Code* c = malloc(sizeof(Code));
        c->place = newTemp();
        c->code = concat($1->code, $3->code);
        char instr[50];
        sprintf(instr, "%s = %s * %s\n", c->place, $1->place, $3->place);
        c->code = concat(c->code, instr);
        $$ = c;
    }
  | factor {
        $$ = $1;
    }
;

factor:
    ID {
        Code* c = malloc(sizeof(Code));
        c->place = $1;
        c->code = strdup("");
        $$ = c;
    }
  | NUM {
        Code* c = malloc(sizeof(Code));
        c->place = $1;
        c->code = strdup("");
        $$ = c;
    }
  | '(' expr ')' {
        $$ = $2;
    }
;

%%

int main() {
    yyparse();
    return 0;
}